mesh-generation execute file could be direct used in different linux system
radiation execute file may be not direct used in different linux system